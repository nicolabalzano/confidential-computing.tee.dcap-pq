/*
 * Copyright (C) 2011-2017 Intel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *   * Neither the name of Intel Corporation nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef _SV_A_LOG_LIB_
#define _SV_A_LOG_LIB_

#define AT_CATEGORY_MAX_LEN               64
#define AT_CASEID_MAX_LEN                 64
#define AT_MESSAGE_MAX_LEN               240
#define AT_FILE_OPEN_MODE               "a+"

#define AT_FLUSH_AFTER_FPRINTF

typedef enum
{
	PASS = 0, 
	FAIL = 1, 
	INFO = 2, 
	START = 3, 
	END   = 4
} AErrorLevel;

typedef enum
{
	ALCSV = 0x08

} ALLOGFORMAT;

typedef int ALLOGMEDIA;
#define ALCONSOLE                        0x01
#define ALFILE                           0x02

#ifdef __cplusplus
extern "C" {
#endif

	int  ALogInit (const char* pszFileName, ALLOGFORMAT type, ALLOGMEDIA media);
	void ALogClose(); 
	void ALogPrint(const char* format, ...);
	void ALogPrintEx(AErrorLevel el, const char* format, ...);
	int  ALogSetCategory(const char* category);
	int  ALogSetCaseID(const char* id);
	int  ALogAssertTrue(int value);
	int  ALogAssertFalse(int value);

#ifdef __cplusplus
}
#endif

#endif
